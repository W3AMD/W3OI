<div id="boxes">

	<div id="dialog" class="window" style="display: none;">
	<a href="#"class="close"/>Close</a>
	<br>
	<img id="bigimage" name="bigimage" src="" />  
	</div>
	<!-- Mask to cover the whole screen -->
	<div id="mask"></div>

</div>
